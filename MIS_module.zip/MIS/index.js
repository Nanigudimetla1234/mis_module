let s=document.getElementById('select');
let z=document.getElementById('insert');
let year=document.getElementById('tablename');
let month=document.getElementById('month');
let btn=document.getElementById('addmore');
let secondoption=document.getElementById('secondoption');
let seminars=['--CHOOSE OPTION','Faculty Related Attended','Faculty Related-Conducted','Student Related Attended','Student Related Conducted'];
let paperpresentations=['--CHOOSE OPTION','Faculty Related','StudentsRelated'];
let count=0;
let temp=0;
s.addEventListener('change',()=>{
  var x = s.options[s.selectedIndex].value;

  if(x=='a' || x=='d' || x=='d' || x=='e' || x=='f' || x=='g' || x=='h' || x=='i' || x=='j' ){
         let text=document.createElement('textarea');
         text.type="textarea";
         text.classList.add('form-select');
         text.id="text-id";
         temp=temp+1
         btn.style.display="block";
         z.appendChild(text);
  }

  if(x=='b'){
     let y=document.createElement('select');
     y.id="seminars";
     y.classList.add('form-select');
     for(i=0;i<seminars.length;i++){
     let option=document.createElement('option');
     option.value=seminars[i];
     option.text=seminars[i];
     y.appendChild(option); 
     }
     secondoption.appendChild(y); 
      let secondselect=document.getElementById('seminars');
       secondselect.addEventListener('change',()=>{
           count++;
           if(count<=1){
         let text=document.createElement('textarea');
         text.classList.add('form-control');
         text.type="textarea";
         text.id="text-id";
         temp=temp+1;
         btn.style.display="block";
         z.appendChild(text);
     }}
     )
  }

  if(x=='c'){
    let y=document.createElement('select');
     y.id="paperpresentations";
     y.classList.add('form-select');
     for(i=0;i<paperpresentations.length;i++){
     let option=document.createElement('option');
     option.value=paperpresentations[i];
     option.text=paperpresentations[i];
     y.appendChild(option); 
     }
     secondoption.appendChild(y); 
      let secondselect=document.getElementById('paperpresentations');
       secondselect.addEventListener('change',()=>{
        z.innerHTML="";   
           count++;
           if(count<=1){
         let text=document.createElement('textarea');
          text.classList.add('form-control');
         text.id="text-id";
         temp=temp+1
         btn.style.display="block";
         z.appendChild(text);
     }}
     )

  }

})
function addmore(){
          let text=document.createElement('textarea');
          text.classList.add('form-control');
          text.id="text-id";
          temp=temp+1;
          z.appendChild(text);
}
function display(){
  var x = s.options[s.selectedIndex].value;
  str="";
  console.log(temp);
  for (i=0;i<temp;i++){
       strings=document.querySelectorAll('#text-id')[i].value;
       str=str+strings+'//';
       console.log(str);
      
  }
  if(x=='a' || x=='d' || x=='d' || x=='e' || x=='f' || x=='g' || x=='h' || x=='i' || x=='j' ){
    let firsts = s.options[s.selectedIndex].innerHTML;
    let first=document.getElementById('first');
    let content=document.getElementById('content');
    first.value=firsts;
    content.value=str;
    month.value=year.value;
  }
  if(x=='b'){
    let firsts = s.options[s.selectedIndex].innerHTML;
    let first=document.getElementById('first');
    let content=document.getElementById('content');
    first.value=firsts;
    content.value=str;
    month.value=year.value;
    console.log(year.value)
    console.log(first.value);
        console.log(content.value)
        
        let seminars=document.getElementById('seminars');
        let seconds = seminars.options[seminars.selectedIndex].text;
        let second=document.getElementById('second');
        second.value=seconds;
        console.log(second.value);
  }
  if(x=='c'){
    let firsts = s.options[s.selectedIndex].innerHTML;
    let first=document.getElementById('first');
    let content=document.getElementById('content');
    first.value=firsts;
    content.value=str;
    month.value=year.value;
    let paperpresentationss=document.getElementById('paperpresentations');
    let seconds = paperpresentationss.options[paperpresentationss.selectedIndex].text;
    let second=document.getElementById('second');
    second.value=seconds;
  }
}