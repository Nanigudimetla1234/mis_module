<?php
    if(isset($_POST['submit']))
    {
        require('db.php');
        $user=trim($_POST['user']);
        $pwd=trim($_POST['password']);
        $rep_pwd=trim($_POST['repPassword']);
        if(empty($user) || empty( $pwd) ||empty($rep_pwd) )
        {
            header("Location:../signup.php?error=emptyfields&user=".$user."&pwd=".$pwd);
            exit();
        }
        // else if(!filter_var($user,FILTER_VALIDATE_EMAIL)){
        //     header("Location:../signup.php?error=invalidUsername&pwd=".$pwd);
        //     exit();
        // }
        else if($pwd!==$rep_pwd)
        {
            header("Location:../signup.php?error=PasswordNotMatch&user=".$user);
            exit();
        }
        else{
            $sql='select userid from faculty_login where userid=?';
            $stmt=mysqli_stmt_init($conn);
            if(!mysqli_stmt_prepare($stmt,$sql)){
                header("Location:../signup.php?error=sqlerror1");
                exit();
            }
            else{
                mysqli_stmt_bind_param($stmt,'s',$user);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);
                $rc=mysqli_stmt_num_rows($stmt);
                if($rc>0){
                    header("Location:../signup.php?error=userexists");
                exit();
                }
                else{
                    $sql='insert into faculty_login(userid,password) values(?,?)';
                    $stmt=mysqli_stmt_init($conn);
                    if(!mysqli_stmt_prepare($stmt,$sql)){
                        header("Location:../signup.php?error=sqlerror2");
                        exit();
                    }
                    else{
                        $hashPwd=password_hash($pwd,PASSWORD_DEFAULT);
                        mysqli_stmt_bind_param($stmt,'ss',$user,$hashPwd);
                        mysqli_stmt_execute($stmt);
                        header("Location:../signup.php?signup=success");
                        exit();
                    }
                }
            }
        }
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
    else{
        header("Location:../signup.php");
        exit();
    }