<?php 
    $serverName="localhost";
    $dbUser="root";
    $dbPassword="";
    $dbName="dept";

    $conn=mysqli_connect($serverName,$dbUser, $dbPassword,  $dbName );
    if(!$conn)
    {
        die("Connection Error : ".mysqli_connect_error());
    }