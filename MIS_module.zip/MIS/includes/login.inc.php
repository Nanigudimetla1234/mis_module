<?php
    if(isset($_POST['submit']))
    {
        require('db.php');
        $user=trim($_POST['user']);
        $user_type=trim($_POST['user_type']);
        $pwd=trim($_POST['password']);
        if(empty($user) || empty( $pwd) )
        {
            header("Location:../index.php?error=emptyfields&&user=".$user."&&pwd=".$pwd);
            exit();
        }
        // else if(!filter_var($user,FILTER_VALIDATE_EMAIL)){
        //     header("Location:../index.php?error=invalidUsername&pwd=".$pwd);
        //     exit();
        //}
        else{
            if($user_type=='student_login')
            {
                  $sql="select * from student_login where userid=?";        
            }
            if($user_type=='faculty_login')
            {   
               
                  $sql="select * from faculty_login where userid=?";      
            }  
            $stmt=mysqli_stmt_init($conn);
            if(!mysqli_stmt_prepare($stmt,$sql)){
                header("Location:../index.php?error=sqlerror");
                exit();
            }
            else{
                mysqli_stmt_bind_param($stmt,'s',$user);
                mysqli_stmt_execute($stmt);
                $result=mysqli_stmt_get_result($stmt);
               if($row=mysqli_fetch_assoc($result)){
                   $pwdCheck=password_verify($pwd,$row['password']);
                   if($pwdCheck==false){
                    header("Location:../index.php?error=incorrect password1");
                    exit();
                   }
                   else if ($pwdCheck==true){
                        session_start();
                        if($user_type=='student_login')
                        {
                        $_SESSION['user']=$row['userid'];
                        header("Location: ../student/index.php");
                        }
                        else
                        {
                        $_SESSION['user']=$row['userid'];
                        header("Location: ../faculty/index.php");  
                        }
                   }
                   else{
                    header("Location: ../index.php?error=incorrect password2");
                    exit();
                   }
               }
                
                
            }
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
}
    else{
        header("Location:../index.php");
        exit();
    }