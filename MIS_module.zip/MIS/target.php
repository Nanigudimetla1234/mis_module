<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MIS</title>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body>
  <?php
  $con = new mysqli('localhost', 'root', '', 'mis');
  if (!$con) {
    die(mysqli_error($con));
  }
  if (isset($_POST['submit'])) {
    $first = $_POST['first'];
    $second = $_POST['second'];
    $content = $_POST['content'];
    $month = $_POST['tablename'];
    $tablename = $month."_mis";
    // echo $tablename;
    $sql = "CREATE TABLE IF NOT EXISTS `" . $tablename . "` (event varchar(300),subtype varchar(300),content varchar(700));";
    $result = mysqli_query($con, $sql);
    if ($result) {
    } else {
      die(mysqli_error($con));
    }
    $rowcount = 0;
    $search = "select * from `".$tablename."` where event='".$first."' and subtype='".$second."';";
    if ($result = mysqli_query($con, $search)) {
      $rowcount = mysqli_num_rows($result);

    }
    if ($rowcount == 0) {
      $insertion = "INSERT INTO `" . $tablename . "` (event,subtype,content) VALUES('$first','$second','$content');";
      $executeinsertion = mysqli_query($con, $insertion);
      if ($executeinsertion) {
  ?>
        <script>
          swal("Good job!", "data is inserted!", "success");
          setTimeout(() => {
            window.location.href = "index.php";
          }, 2500);
        </script>
      <?php
      } else {
        die(mysqli_error($con));
      }
    } else {
      ?>
      <script>
        swal("you can't insert again please use update option", "please wait for a while it will redirect to the update page ", "error");
        setTimeout(() => {
          window.location.href = "update.php";
        }, 3000);
      </script>

  <?php
    }
  }
  ?>

</body>

</html>