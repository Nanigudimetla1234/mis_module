<?php
$con = new mysqli('localhost', 'root', '', 'mis');
if (!$con) {
    die(mysqli_error($con));
}
if (isset($_POST['updated'])) {
    $first = $_POST['firstlu'];
    $second = $_POST['secondlu'];
    $data = $_POST['data'];
    $tablename = $_POST['tablename'];
    $update = "UPDATE `$tablename` SET content='" . $data . "' where event='" . $first . "' and subtype='" . $second . "';";
    $exe = mysqli_query($con, $update);
    if($exe){
    }
    else{
        die(mysqli_error($con));
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body>
    <script>
        swal("Good job!", "You Updated successfully!", "success");
    </script>
</body>

</html>