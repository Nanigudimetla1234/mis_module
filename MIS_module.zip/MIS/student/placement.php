<?php
    //if user not logged in redirect to login
    session_start();
    if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Student Portal</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../images/logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <?php 
  require('./includes/db.php');
  require"./includes/navbar.php";
  require"./includes/sidebar.php";
   ?>
   <?php
   if(isset($_POST['get_placed']))
   {
        $roll=$_SESSION['user'];
        $isPlaced=trim($_POST['placed']);
        $company=trim($_POST['company']);
        $sql3='insert into placed_info(`rollNumber`,`placed`,`company`) values(?,?,?)';
        $stmt=mysqli_stmt_init($conn);
        mysqli_stmt_prepare($stmt,$sql3);
        mysqli_stmt_bind_param($stmt,'sss',$roll,$isPlaced,$company);
        mysqli_stmt_execute($stmt);
   }
   ?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1>Eligiblity</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Eligibility</li>
                    <li class="breadcrumb-item active">Eligibility List</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <div class="col-12">
<div class="col-12">
  <div id="right-frame">
       <?php
     $rollnumber=$_SESSION['user'];
     $sql='select * from cmpstudinfo where Roll=?';

     $stmt=mysqli_stmt_init($conn);
     if(!mysqli_stmt_prepare($stmt,$sql)){
        header("Location:./placement.php?error=sqlerror");
        exit();
    }
    else{
        mysqli_stmt_bind_param($stmt,'s',$rollnumber);
        mysqli_stmt_execute($stmt);
        $result=mysqli_stmt_get_result($stmt);
        $row=mysqli_fetch_assoc($result);
        if($row)
        {
            $ten=$row['tenPer'];
            $inter=$row['interPer'];
            $eng=$row['engPer'];
            $blogs=$row['Blogs'];
            $sql2="select * from companies where tenPer<=? and interPer<=? and engPer<=? and Backlogs>=?";
            if(!mysqli_stmt_prepare($stmt,$sql2))
            {
                header("Location:./placement.php?error=internalerror");
                echo $sql2;
                exit();
            }
            mysqli_stmt_bind_param($stmt,'dddi',$ten,$inter,$eng,$blogs);
            mysqli_stmt_execute($stmt);
        $result2=mysqli_stmt_get_result($stmt);
       
            if (mysqli_num_rows($result2)) 
        {
    while($row = mysqli_fetch_array($result2)) {
?>
          <div class="card">
            <div class="card-body pt-3">
              <div class="tab-content pt-2">

                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                  <h5 class="card-title">Drive Details</h5>

                  <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Company Name :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Name"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">Drive Name :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Drive"]; ?></div>
                  </div>
                  
                   <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Drive Date :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["driveDate"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">Role :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Role"]; ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Branches Eligible :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Branches"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">Xth Percentage:</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["tenPer"]; ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-3 label ">XII th Percentage :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["interPer"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">B.Tech Percentage :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["engPer"]; ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Max No:of Backlogs :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Backlogs"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">Package :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Package"]; ?></div>
                  </div>

                   <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Bond :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Bond"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">PPO :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["PPO"]; ?></div>
                  </div>

                   <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Oncampus or Offcampus :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Type"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">Registration Link :</div>
                    <div class="col-lg-3 col-md-3"><a target="_blank"href='<?php echo ' '.$row["Link"]; ?>'>&nbspRegister</a></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-3 label ">Description :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["Descr"]; ?></div>
                     <div class="col-lg-3 col-md-3 label ">End Date :</div>
                    <div class="col-lg-3 col-md-3"><?php echo ' '.$row["endDate"]; ?></div>
                  </div>
                <?php
                
                $sql='select * from placed_info where rollNumber=? and company=?';
                $stmt=mysqli_stmt_init($conn);
                mysqli_stmt_prepare($stmt,$sql);
                mysqli_stmt_bind_param($stmt,'ss',$rollnumber,$row["Name"]);
                mysqli_stmt_execute($stmt);
                $result=mysqli_stmt_get_result($stmt);
                $row_placed=mysqli_fetch_assoc($result);
                if(!$row_placed)
                {
                ?>  
                <form action="" method="post">
                   <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Are you Placed?</label>
                  <div class="col-3">
                    <select class="form-select" name="placed" aria-label="Default select example">
                        <option selected>choose your choice</option>
                      <option value="yes">Yes</option>
                      <option value="no">No</option>
                    </select>
                  </div>
                  <input type="hidden" name="company" value="<?php echo $row["Name"];?>">
                  <div class="col-3">
                    <input type="submit" name="get_placed" value="submit" class="btn btn-primary">
                  </div>
    </form>
    <?php
    }
    ?>
                </div>
                  
                </div>


            </div>
          </div>

        </div> 
         <?php
}
?>
<?php
        }
        }
        else{
            echo `<h1>You are not eligible for any placements</h1>`;
                exit();
        }
    }
        
?>
	


        

    </main><!-- End #main -->


  <!-- ======= Footer ======= -->
  <?php require"./includes/footer.php";?>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>