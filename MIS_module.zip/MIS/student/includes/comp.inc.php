<?php
    if(isset($_POST['offer-submit']))
    {
        require('db.php');
        $cmp=trim($_POST['company-name']);
        $drv=trim($_POST['drive-name']);
        $drvdt=trim($_POST['drive-date']);
        $role=trim($_POST['job-role']);
        $branch=trim($_POST['branch']);
        $tp=trim($_POST['tenPer']);
        $ip=trim($_POST['interPer']);
        $ep=trim($_POST['engPer']);
        $blogs=trim($_POST['blogs']);
        $package=trim($_POST['package']);
        $bond=trim($_POST['bond']);
        $ppo=trim($_POST['ppo']);
        $ptype=trim($_POST['Cmp']);
        $link=trim($_POST['regLink']);
        $desc=trim($_POST['bio']);
        $eDate=trim($_POST['regDate']);
        $circular=trim($_POST['circular']);
        $elig=trim($_POST['eligibility']);
        if(empty($cmp) || empty($drv) || empty($drvdt) || empty($role) || empty($branch) || empty($tp) || empty($ip) || empty($ep) ||  empty($package)|| empty($ppo) || empty($ptype) || empty($link) || empty($desc) || empty($eDate))
        {
            header("Location:../add_offer.php?error=emptyfields");
            exit();
        }
        else{
            $sql="insert into companies(`Name`, `Drive`, `driveDate`, `Role`, `Branches`, `tenPer`, `interPer`, `engPer`, `Backlogs`, `Package`, `Bond`, `PPO`, `Type`, `Link`, `Descr`, `endDate`, `Circular`, `Eligibility`) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt=mysqli_stmt_init($conn);
            if(!mysqli_stmt_prepare($stmt,$sql)){
                header("Location:../add_offer.php?error=sqlerror");
                exit();
            }
            else{
                mysqli_stmt_bind_param($stmt,'sssssdddiiisssssss',$cmp,$drv,$drvdt, $role,$branch,$tp,$ip,$ep,$blogs,$package,$bond,$ppo,$ptype,$link, $desc,$eDate,$circular,$elig);
                $chk=mysqli_stmt_execute($stmt);

               if($chk==true){
                    header("Location:../view_offers.php");
                    exit();
                   }
                   
                   else{
                    header("Location:../add_offers.php?error=notInserted");
                    exit();
                   }
               }
                
                
            }
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
}
    else{
        header("Location:../add_offer.php");
        exit();
    }