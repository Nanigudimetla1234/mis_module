<?php
$con = new mysqli('localhost', 'root', '', 'mis');
echo "hi";
if(isset($_POST['display'])){
    echo "hi";
    $month = $_POST['month'];
    $tablename = $month."_mis";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Departmental Website</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="images/logo.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        li {
            font-size: 16px;
            word-break: break-word;
            overflow-wrap: break-word;
        } 
    </style>
</head>

<body>

    <?php require "./includes/navbar.php";
    require "./includes/sidebar.php";
    ?>


    <main id="main" class="main">
        <table class="table " id="tab">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">event</th>
                    <th scope="col">subtype</th>
                    <th scope="col">content</th>
                </tr>
            </thead>
            <?php
            $fetch = "select * from `$tablename` where approval='1';";
            $exe = mysqli_query($con, $fetch);

            while ($row = mysqli_fetch_assoc($exe)) {
                extract($row);
                $temp = substr_count($content, '//');
                $content_array = explode('//', $content);
            ?>
                <tbody>
                    <tr>
                        <td><?php echo $event ?></td>
                        <td><?php echo $subtype ?></td>
                        <td>
                            <ul>
                                <?php
                                for ($i = 0; $i < $temp; $i++) {
                                ?>
                                    <li id="<?php echo $i; ?>"><?php echo $content_array[$i]; ?></li>
                                <?php
                                }
                                ?>
                            </ul>
                        </td>
                    </tr>
                </tbody>
            <?php
            }
            ?>
        </table>
        <div style="display: flex; justify-content:center;">

            <input class="btn btn-primary" type="button" value="Print Table" onclick="myApp.printTable()" />
        </div>
        <script>
            var myApp = new function() {
                this.printTable = function() {
                    var tab = document.getElementById('tab');
                    var win = window.open('', '', 'height=700,width=700');
                    win.document.write(tab.outerHTML);
                    win.document.close();
                    win.print();
                }
            }
        </script>




    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <?php require "./includes/footer.php"; ?>
    <!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chart.js/chart.min.js"></script>
    <script src="assets/vendor/echarts/echarts.min.js"></script>
    <script src="assets/vendor/quill/quill.min.js"></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>